// Define a global variable for the base path
const BASE_PATH = "/MPBuddy";