// View: Manages DOM updates

const appViewModel = new AppViewModel(); // Initialize ViewModel

async function renderContent() {
    const xmlFilePath = `${BASE_PATH}/data/folder1/file1.xml`; // XML file path
    const templateFilePath = `${BASE_PATH}/templates/template1.html`; // Template file path

    const { items, template, error } = await appViewModel.loadContent(xmlFilePath, templateFilePath);
    const contentDiv = document.getElementById("content");

    if (error) {
        contentDiv.innerHTML = `<div class="no-data">${error}</div>`;
        return;
    }

    items.forEach(item => {
        const clone = template.cloneNode(true);
        clone.querySelector(".title").textContent = item.title;
        clone.querySelector(".description").textContent = item.description;
        contentDiv.appendChild(clone);
    });
}

// Trigger rendering
renderContent();